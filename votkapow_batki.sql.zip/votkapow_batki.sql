-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2022 at 12:28 AM
-- Server version: 10.3.32-MariaDB-log-cll-lve
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votkapow_batki`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin-post`
--

CREATE TABLE IF NOT EXISTS `admin-post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(50) NOT NULL,
  `subj` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `type` enum('report','msg') NOT NULL DEFAULT 'msg',
  `new` enum('true','false') NOT NULL DEFAULT 'true',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `admin-post`
--

TRUNCATE TABLE `admin-post`;
-- --------------------------------------------------------

--
-- Table structure for table `admin-toto-lotary-stats`
--

CREATE TABLE IF NOT EXISTS `admin-toto-lotary-stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `chisla` int(11) NOT NULL COMMENT '# POZNATI CHISLA',
  `what` enum('lotary','toto') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `admin-toto-lotary-stats`
--

TRUNCATE TABLE `admin-toto-lotary-stats`;
--
-- Dumping data for table `admin-toto-lotary-stats`
--

INSERT INTO `admin-toto-lotary-stats` (`id`, `username`, `timestamp`, `chisla`, `what`) VALUES
(1, 'kras79', 1424369123, 0, 'lotary'),
(2, 'kras79', 1424771053, 0, 'lotary'),
(3, 'kras79', 0, 5, 'toto'),
(4, 'kras79', 1426881712, 0, 'lotary');

-- --------------------------------------------------------

--
-- Table structure for table `bought_products`
--

CREATE TABLE IF NOT EXISTS `bought_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(70) NOT NULL,
  `product_id` int(11) NOT NULL,
  `start-time` int(11) NOT NULL,
  `end-time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=315 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `bought_products`
--

TRUNCATE TABLE `bought_products`;
-- --------------------------------------------------------

--
-- Table structure for table `charecters`
--

CREATE TABLE IF NOT EXISTS `charecters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `level` int(11) NOT NULL,
  `exp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `charecters`
--

TRUNCATE TABLE `charecters`;
--
-- Dumping data for table `charecters`
--

INSERT INTO `charecters` (`id`, `name`, `image`, `level`, `exp`) VALUES
(1, 'Герой 1', 'http://www.leanerbydesign.com/wp-content/uploads/2014/02/Fat-Bloke1.jpg?8ce9d0', 1, 0),
(2, 'Герой 2', 'http://bbsimg.ngfiles.com/1/16011000/ngbbs47fd3bb4b04e2.jpg', 2, 0),
(3, 'Герой 3', 'http://guidowatch.typepad.com/.a/6a0120a51d52b4970b0120a6affa2b970c-800wi', 3, 754),
(4, 'Герой 4', 'http://www.adviceforpersonaltrainers.com/blog/wp-content/uploads/2009/12/fat-guy-exercising-200x300.jpg', 4, 980),
(5, 'Герой 5', 'http://watermarked.cutcaster.com/cutcaster-photo-801069595-Guy-with-tablet-and-without-shirt.jpg', 5, 5477),
(6, 'Герой 6', 'http://us.123rf.com/450wm/rido/rido1201/rido120100036/12155611-strong-young-man-lifting-weight-for-fitness-exercise-isolated-on-white-background.jpg', 6, 75000),
(8, 'Герой 7', 'http://www.theelitephysique.com/images/man-before.JPG', 7, 0),
(9, 'Герой 8', 'http://www.cureviewscam.com/wp-content/uploads/2012/02/Jesse-Vince.jpg', 8, 0),
(10, 'Герой 9', 'http://hghsupplementsworld.com/wp-content/uploads/2012/04/Bodybuilding_and_HGH_Supplements-294x300.jpg', 9, 0),
(11, 'Герой 10', 'http://www.skinnyguybuildmuscle.com/wp-content/uploads/2010/11/2049834_f2601.jpg', 10, 0),
(12, 'Герой 11', 'http://www.myfitnessstudio.co.uk/wp-content/uploads/nickauger.jpg', 11, 0),
(13, 'Герой 12', 'http://hghsupplementsreport.org/wp-content/uploads/2013/06/hgh-bodybuilding-253x300.jpg', 12, 0),
(14, 'Герой 13', 'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTgD0waTvwYwdWYxVaW0X28UFDHoJW7Qpwn4pxTDQydYmyRy1WU', 13, 0),
(15, 'Герой 14', 'http://1.bp.blogspot.com/_2atiiVp-r8s/TU0G4bB0wDI/AAAAAAAACOI/qnlapPTpxVs/s1600/best+bodybuilders+images771.jpg', 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `cities`
--

TRUNCATE TABLE `cities`;
--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`) VALUES
(1, 'Айтос\r\n'),
(2, 'Асеновград (Станимака)\r\n'),
(3, 'Ахтопол\r\n'),
(4, 'Балчик\r\n'),
(5, 'Банкя\r\n'),
(6, 'Банско\r\n'),
(7, 'Батак\r\n'),
(8, 'Белене\r\n'),
(9, 'Белица\r\n'),
(10, 'Белослав (Гебедже)\r\n'),
(11, 'Берковица\r\n'),
(12, 'Битоля\r\n'),
(13, 'Благоевград (Горна Джумая)\r\n'),
(14, 'Ботевград\r\n'),
(15, 'Брацигово\r\n'),
(16, 'Брезник\r\n'),
(17, 'Бургас\r\n'),
(18, 'Бяла \r\n'),
(19, 'Варна\r\n'),
(20, 'Велес\r\n'),
(21, 'Велики Преслав\r\n'),
(22, 'Велико Търново\r\n'),
(23, 'Велинград\r\n'),
(24, 'Видин \r\n'),
(25, 'Враца\r\n'),
(26, 'Вършец\r\n'),
(27, 'Габрово\r\n'),
(28, 'Гевгели\r\n'),
(29, 'Горна Оряховица\r\n'),
(30, 'Гоце Делчев (Неврокоп)\r\n'),
(31, 'Гюмюрджина (Комотини)\r\n'),
(32, 'Дедеагач\r\n'),
(33, 'Демир Хисар\r\n'),
(34, 'Димитровград\r\n'),
(35, 'Добрич (Толбухин)\r\n'),
(36, 'Дойран\r\n'),
(37, 'Долна Баня\r\n'),
(38, 'Долна Оряховица\r\n'),
(39, 'Долни Дъбник\r\n'),
(40, 'Драма\r\n'),
(41, 'Дупница\r\n'),
(42, 'Елена\r\n'),
(43, 'Исперих\r\n'),
(44, 'Ихтиман\r\n'),
(45, 'Кавала\r\n'),
(46, 'Каварна\r\n'),
(47, 'Казанлък\r\n'),
(48, 'Калофер\r\n'),
(49, 'Карлово\r\n'),
(50, 'Карнобат\r\n'),
(51, 'Кешан\r\n'),
(52, 'Китен \r\n'),
(53, 'Козлодуй\r\n'),
(54, 'Копривщица\r\n'),
(55, 'Костенец\r\n'),
(56, 'Костур\r\n'),
(57, 'Котел\r\n'),
(58, 'Кресна\r\n'),
(59, 'Крушево\r\n'),
(60, 'Ксанти\r\n'),
(61, 'Кукуш\r\n'),
(62, 'Кърджали\r\n'),
(63, 'Кюстендил\r\n'),
(64, 'Лерин\r\n'),
(65, 'Ловеч\r\n'),
(66, 'Лозенград\r\n'),
(67, 'Лом\r\n'),
(68, 'Люле Бургас\r\n'),
(69, 'Мадан\r\n'),
(70, 'Мелник\r\n'),
(71, 'Момчилград\r\n'),
(72, 'Монтана (Кутловица)\r\n'),
(73, 'Несебър\r\n'),
(74, 'Никопол\r\n'),
(75, 'Ниш\r\n'),
(76, 'Нова Загора\r\n'),
(77, 'Обзор\r\n'),
(78, 'Одрин\r\n'),
(79, 'Оряхово\r\n'),
(80, 'Охрид\r\n'),
(81, 'Павликени\r\n'),
(82, 'Пазарджик\r\n'),
(83, 'Панагюрище\r\n'),
(84, 'Перник\r\n'),
(85, 'Перущица\r\n'),
(86, 'Петрич\r\n'),
(87, 'Пещера\r\n'),
(88, 'Пирдоп\r\n'),
(89, 'Плевен\r\n'),
(90, 'Пловдив\r\n'),
(91, 'Поморие\r\n'),
(92, 'Попово\r\n'),
(93, 'Пордим\r\n'),
(94, 'Правец\r\n'),
(95, 'Прилеп\r\n'),
(96, 'Приморско\r\n'),
(97, 'Провадия\r\n'),
(98, 'Първомай\r\n'),
(99, 'Радомир\r\n'),
(100, 'Разград\r\n'),
(101, 'Разлог\r\n'),
(102, 'Русе\r\n'),
(103, 'Самоков\r\n'),
(104, 'Сандански (Свети Врач)\r\n'),
(105, 'Свиленград (Мустафа паша)\r\n'),
(106, 'Свищов\r\n'),
(107, 'Своге\r\n'),
(108, 'Севлиево\r\n'),
(109, 'Серес (Сер, Сяр)\r\n'),
(110, 'Силистра\r\n'),
(111, 'Симеоновград\r\n'),
(112, 'Скопие\r\n'),
(113, 'Сливен\r\n'),
(114, 'Смолян\r\n'),
(115, 'Созопол\r\n'),
(116, 'Солун\r\n'),
(117, 'Сопот\r\n'),
(118, 'София\r\n'),
(119, 'Стара Загора\r\n'),
(120, 'Стражица\r\n'),
(121, 'Струга\r\n'),
(122, 'Струмица\r\n'),
(123, 'Тетово\r\n'),
(124, 'Тополовград\r\n'),
(125, 'Троян\r\n'),
(126, 'Трън\r\n'),
(127, 'Тулча\r\n'),
(128, 'Тутракан\r\n'),
(129, 'Търговище\r\n'),
(130, 'Харманли\r\n'),
(131, 'Хасково\r\n'),
(132, 'Хисар\r\n'),
(133, 'Царево (Мичурин)\r\n'),
(134, 'Цариброд\r\n'),
(135, 'Цариград\r\n'),
(136, 'Чаталджа\r\n'),
(137, 'Чепеларе\r\n'),
(138, 'Червен бряг\r\n'),
(139, 'Чирпан\r\n'),
(140, 'Чорлу\r\n'),
(141, 'Шумен\r\n'),
(142, 'Щип\r\n'),
(143, 'Якоруда\r\n'),
(144, 'Ямбол');

-- --------------------------------------------------------

--
-- Table structure for table `fitness`
--

CREATE TABLE IF NOT EXISTS `fitness` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `need-energy` int(11) NOT NULL DEFAULT 5,
  `need-lvl` int(11) NOT NULL DEFAULT 1,
  `price` int(11) NOT NULL,
  `exp-boost` int(11) NOT NULL,
  `work-in-minutes` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `fitness`
--

TRUNCATE TABLE `fitness`;
--
-- Dumping data for table `fitness`
--

INSERT INTO `fitness` (`id`, `title`, `need-energy`, `need-lvl`, `price`, `exp-boost`, `work-in-minutes`) VALUES
(1, 'Бягай на пътеката', 5, 1, 10, 30, 1),
(2, 'Вдигай Дъмбели - 3 кг.', 10, 1, 20, 50, 1),
(3, 'Вдигай Дъмбели - 5 кг.', 20, 1, 30, 70, 3),
(4, 'Вдигай от лежанка - 10 кг.', 20, 2, 30, 100, 5),
(5, 'Вдигане на щанга - силово [6 повторения]', 5, 1, 50, 130, 4),
(6, 'Вдигане на щанга от наклонен лег [6-7 повторениия]', 10, 1, 10, 80, 2),
(7, 'Вдигане на Мъртва тяга - 50кг. [6 повторения]', 15, 2, 30, 80, 2),
(8, 'Вдигане на дъмбел - поза ЧУК [6-7 повторения]', 15, 1, 50, 60, 3);

-- --------------------------------------------------------

--
-- Table structure for table `gifts-given`
--

CREATE TABLE IF NOT EXISTS `gifts-given` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `end-time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=554 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `gifts-given`
--

TRUNCATE TABLE `gifts-given`;
-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `exp-boost` int(11) NOT NULL,
  `work-time-minutes` int(11) NOT NULL,
  `money-boost` int(11) NOT NULL,
  `need-energy` int(11) NOT NULL DEFAULT 10,
  `neaded-lvl` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jobs`
--

TRUNCATE TABLE `jobs`;
--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `exp-boost`, `work-time-minutes`, `money-boost`, `need-energy`, `neaded-lvl`) VALUES
(1, 'Изчисти на баба си къщата', 10, 30, 10, 20, 1),
(2, 'Изхвърли боклука', 3, 2, 5, 15, 1),
(3, 'Раходи кучето на съседа', 5, 1, 3, 5, 1),
(4, 'Почисти мазето', 5, 8, 20, 10, 1),
(5, 'Дари старите си дрехи на бедните', 30, 5, 0, 20, 2),
(6, 'Изчисти пред блока', 5, 5, 30, 15, 1),
(7, 'Замествай продавачката в магазина', 40, 70, 100, 100, 1),
(8, 'Склад - разносвач', 30, 60, 80, 20, 2),
(9, 'Стани Дюнерджия', 10, 120, 100, 100, 2),
(10, 'Стани барман', 30, 120, 120, 100, 3),
(11, 'Стани частен фитнес интруктор', 70, 240, 200, 80, 4),
(12, 'Замествай учителя по физическо', 50, 90, 60, 30, 3),
(13, 'Замести касиера във фитнеса за 2 часа', 20, 10, 50, 10, 1),
(14, 'Замести касиера във фитнеса за 4 часа', 30, 20, 75, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `map-points`
--

CREATE TABLE IF NOT EXISTS `map-points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '(просто точка)',
  `url` varchar(300) NOT NULL,
  `x` int(11) NOT NULL DEFAULT 0,
  `y` int(11) NOT NULL DEFAULT 0,
  `need-level` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `map-points`
--

TRUNCATE TABLE `map-points`;
--
-- Dumping data for table `map-points`
--

INSERT INTO `map-points` (`id`, `title`, `url`, `x`, `y`, `need-level`) VALUES
(1, 'Работа', './?p=work', 320, 187, 1),
(2, 'Фитнес', './?p=fitness', 435, 105, 1),
(3, 'Магазин', './?p=shop', 310, 100, 1),
(4, 'Лотария', './?p=lotary', 250, 300, 3),
(5, 'ТОТО 6/49', './?p=toto', 340, 300, 5),
(6, 'Лостове', './?p=streetfitness', 450, 240, 10);

-- --------------------------------------------------------

--
-- Table structure for table `resting`
--

CREATE TABLE IF NOT EXISTS `resting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `time-in-min` int(11) NOT NULL DEFAULT 1,
  `timestamp-end` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1123 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `resting`
--

TRUNCATE TABLE `resting`; 

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE IF NOT EXISTS `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) NOT NULL DEFAULT '(Няма заглавие)',
  `exp-boost` int(11) NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL DEFAULT 0,
  `days-for-use` int(11) NOT NULL DEFAULT 30,
  `fat-burn` float NOT NULL DEFAULT 0.1,
  `neaded-lvl` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `shop`
--

TRUNCATE TABLE `shop`;
--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`id`, `title`, `exp-boost`, `price`, `days-for-use`, `fat-burn`, `neaded-lvl`) VALUES
(1, 'Креатин', 150, 400, 15, 0, 3),
(2, 'Протеин', 100, 570, 20, 0, 3),
(3, 'Протеинов шейк', 100, 50, 1, 0, 1),
(4, 'Суроватъчен протеин ', 140, 100, 2, 0, 2),
(5, 'Млечен протеин ', 120, 60, 1, 0.1, 2),
(6, 'Cоев протеин', 95, 300, 3, 0.1, 3),
(7, 'Яйчен протеин ', 100, 280, 5, 0.1, 3),
(8, '500гр. чисти ядки', 70, 20, 1, 0.1, 1),
(9, 'Здравословна салата', 50, 15, 1, 0.1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `streetfitness`
--

CREATE TABLE IF NOT EXISTS `streetfitness` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `exp-boost` int(11) NOT NULL,
  `need-energy` int(11) NOT NULL,
  `need-lvl` int(11) NOT NULL DEFAULT 10,
  `price` int(11) NOT NULL DEFAULT 10,
  `work-in-minutes` int(11) NOT NULL DEFAULT 10,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `streetfitness`
--

TRUNCATE TABLE `streetfitness`;
--
-- Dumping data for table `streetfitness`
--

INSERT INTO `streetfitness` (`id`, `title`, `exp-boost`, `need-energy`, `need-lvl`, `price`, `work-in-minutes`) VALUES
(1, '10 Набирания за бицепс', 50, 10, 10, 10, 5),
(2, '15 Набирания за бицепс', 70, 20, 11, 20, 10),
(3, '10 Набирания с обратен загват', 50, 15, 10, 20, 7),
(4, '15 Набирания с обратен загват', 70, 25, 11, 30, 7),
(5, '10 Лицеви опори с нормален захват', 50, 10, 10, 20, 5),
(6, '15 Лицеви опори с нормален захват', 70, 20, 11, 30, 10),
(7, '10 Лицеви опори с широк захват', 70, 20, 10, 20, 5),
(8, '15 Лицеви опори с широк захват', 90, 30, 11, 30, 7);

-- --------------------------------------------------------

--
-- Table structure for table `training`
--

CREATE TABLE IF NOT EXISTS `training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `fitness_id` int(11) NOT NULL,
  `type` enum('fitness','streetfitness') NOT NULL DEFAULT 'fitness',
  `start-time` int(11) NOT NULL,
  `end-time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5491 DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `training`
--

TRUNCATE TABLE `training`;
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) CHARACTER SET latin1 NOT NULL,
  `money` int(11) NOT NULL DEFAULT 0,
  `exp` int(11) NOT NULL DEFAULT 0,
  `charecter` int(3) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `display-name` varchar(150) NOT NULL,
  `city` int(11) NOT NULL,
  `energy` int(11) NOT NULL DEFAULT 100,
  `gener` enum('1','2') NOT NULL DEFAULT '1',
  `confirmed` enum('true','false') NOT NULL DEFAULT 'false',
  `reg_date` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `confirm-key` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `type` enum('user','admin') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=341 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `visits-stats`
--

CREATE TABLE IF NOT EXISTS `visits-stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `full_url` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `working`
--

CREATE TABLE IF NOT EXISTS `working` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `username` varchar(70) NOT NULL,
  `start-time` int(11) NOT NULL,
  `end-time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2226 DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
